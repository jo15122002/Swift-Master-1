//
//  Utilities.swift
//  SwiftUI_BLE
//
//  Created by digital on 08/11/2023.
//

import Foundation

typealias ModelProtocol = Identifiable & Equatable
